"""Planner Skill test suite."""
