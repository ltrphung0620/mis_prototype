"""End-to-end tests for the durable one-call automatic Initial Assessment workflow."""

import asyncio
import time
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from opc_mis.api.application import create_app
from opc_mis.domain.case_workflow_models import CaseWorkflowRun
from opc_mis.domain.enums import EvaluationScope, WorkflowStatus
from opc_mis.domain.workflow import WorkflowNode
from opc_mis.infrastructure.excel.dataset_adapter import ExcelDatasetIngestion
from opc_mis.infrastructure.excel.workbook_loader import compute_sha256
from opc_mis.infrastructure.persistence.memory_dataset_repository import (
    InMemoryDatasetRepository,
)
from opc_mis.infrastructure.persistence.sqlite_database import SQLiteDatabase
from opc_mis.infrastructure.persistence.sqlite_workflow_repository import (
    SQLiteCaseWorkflowRepository,
)

TEAM_PACK = Path("data/input/MISTalent2026_OPC_AgenticAI_TeamPack_v3.xlsx").resolve()
FULL_SCOPE = ["FINANCE", "OPERATIONS", "RISK"]
PLANNER_PERFORMANCE_BOND_AMOUNT = 420_000_000
TEST_HMAC_KEY = "MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWY="


@pytest.fixture(scope="module")
def workflow_client() -> Iterator[TestClient]:
    patcher = pytest.MonkeyPatch()
    patcher.setenv("OPENAI_ENABLED", "false")
    patcher.setenv("OPC_MIS_MASKING_HMAC_KEY_BASE64", TEST_HMAC_KEY)
    try:
        app = create_app(
            workbook_path=TEAM_PACK,
            dataset_id="AUTOMATIC_WORKFLOW_TEST",
            database_path=":memory:",
        )
        with TestClient(app) as client:
            yield client
    finally:
        patcher.undo()


def start(client: TestClient, contract_id: str) -> dict[str, object]:
    response = client.post(
        "/api/cases/run",
        json={
            "contract_id": contract_id,
            "evaluation_scope": FULL_SCOPE,
            "as_of_date": "2026-07-16",
        },
    )
    assert response.status_code == 202
    return response.json()


def wait_for_terminal(
    client: TestClient,
    workflow_run_id: str,
    *,
    timeout_seconds: float = 10,
) -> dict[str, object]:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        response = client.get(f"/api/workflows/{workflow_run_id}")
        assert response.status_code == 200
        payload = response.json()
        if payload["status"] not in {"PENDING", "RUNNING"}:
            return payload
        time.sleep(0.02)
    raise AssertionError("Automatic workflow did not reach a terminal/wait state in time.")


def complete_banking_pause_if_required(
    client: TestClient,
    summary: dict[str, object],
) -> dict[str, object]:
    """Resolve Governance and document pauses while leaving direct routes unchanged."""
    current = summary
    for _ in range(6):
        if current["status"] == "WAITING_FOR_INPUT" and current[
            "current_stage"
        ] == "DOCUMENT_PREPARATION":
            pending_ids = current["pending_missing_data_ids"]
            assert isinstance(pending_ids, list)
            assert pending_ids
            evaluation_case_id = str(current["evaluation_case_id"])
            artifacts = client.get(
                f"/api/cases/{evaluation_case_id}/artifacts"
            ).json()
            checklist = next(
                item
                for item in reversed(artifacts)
                if item["artifact_type"] == "DOCUMENT_CHECKLIST"
            )
            document_type = next(
                item["document_code"]
                for item in checklist["payload"]["items"]
                if item["missing_request_id"] == pending_ids[0]
            )
            accepted = client.post(
                f"/api/cases/{evaluation_case_id}/documents/evidence-supplements",
                json={
                    "workflow_run_id": current["workflow_run_id"],
                    "missing_request_id": pending_ids[0],
                    "document_reference_id": (
                        "DOCREF-00000000-0000-4000-8000-000000000002"
                        if document_type == "PERFORMANCE_BOND_REQUEST_FORM"
                        else "DOCREF-00000000-0000-4000-8000-000000000005"
                    ),
                    "content_sha256": "b" * 64,
                    "document_type": document_type,
                    "evidence_note": "REQUESTED_DOCUMENT_REFERENCE_SUPPLIED",
                },
            )
            assert accepted.status_code == 202
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                candidate = client.get(
                    f"/api/workflows/{current['workflow_run_id']}"
                ).json()
                durable = candidate["status"] not in {"PENDING", "RUNNING"}
                document_was_applied = pending_ids[0] not in candidate[
                    "pending_missing_data_ids"
                ]
                if durable and document_was_applied:
                    current = candidate
                    break
                time.sleep(0.02)
            else:
                raise AssertionError("Document supplement was not applied in time.")
            continue
        if current["status"] == "WAITING_FOR_APPROVAL":
            evaluation_case_id = str(current["evaluation_case_id"])
            pending_ids = current["pending_approval_ids"]
            assert isinstance(pending_ids, list)
            assert len(pending_ids) == 1
            requests = client.get(
                f"/api/cases/{evaluation_case_id}/approval-requests"
            ).json()
            pending_request = next(
                item for item in requests if item["request_id"] == pending_ids[0]
            )
            action_type = pending_request["command"]["action_type"]
            assert action_type in {
                "SUBMIT_BANKING_PRECHECK",
                "CONFIRM_FINAL_CONTRACT_DECISION",
            }
            approved = client.post(
                f"/api/approval-requests/{pending_ids[0]}/decision",
                json={
                    "decision": "APPROVE",
                    "decided_by": "FOUNDER",
                    "reason": "HUMAN_REVIEW_COMPLETED",
                },
            )
            assert approved.status_code == 200
            assert approved.json()["action_authorized"] is True
            requests = client.get(
                f"/api/cases/{evaluation_case_id}/approval-requests"
            ).json()
            assert any(
                item["request_id"] == pending_ids[0]
                and item["status"] == "APPROVED"
                for item in requests
            )
            current = wait_for_terminal(client, str(current["workflow_run_id"]))
            continue
        return current
    raise AssertionError("Workflow exceeded the expected governed pause sequence.")


def test_con004_uses_planner_amount_then_pauses_for_submission_approval(
    workflow_client: TestClient,
) -> None:
    before = compute_sha256(TEAM_PACK)

    created = start(workflow_client, "CON-004")
    paused = wait_for_terminal(workflow_client, str(created["workflow_run_id"]))

    assert paused["status"] == "WAITING_FOR_APPROVAL"
    assert paused["current_stage"] == "WAITING_FOR_APPROVAL"
    assert paused["resume_stage"] == "BANKING_PRECHECK_SUBMISSION_PROPOSAL"
    assert paused["blocked_action"] == "SUBMIT_BANKING_PRECHECK"
    assert paused["decision_route_outcome"] == "BANKING_DISCOVERY_REQUIRED"
    assert paused["banking_discovery_request_id"]
    assert paused["banking_discovery_status"] == "OPTIONS_READY"
    assert paused["banking_precheck_readiness_status"] == "READY"
    assert paused["decision_post_banking_outcome"] == "BANKING_PRECHECK_READY"
    assert paused["pending_missing_data_ids"] == []
    assert paused["banking_input_supplement_id"] is None
    assert len(paused["pending_approval_ids"]) == 1
    assert paused["banking_precheck_submission_proposal_id"]
    assert paused["banking_precheck_submission_candidate_ids"] == paused[
        "precheck_ready_option_ids"
    ]
    case_id = str(paused["evaluation_case_id"])
    initial_artifacts = workflow_client.get(
        f"/api/cases/{case_id}/artifacts"
    ).json()
    initial_request = next(
        item
        for item in initial_artifacts
        if item["artifact_type"] == "BANKING_DISCOVERY_REQUEST"
    )
    initial_matrix = next(
        item
        for item in initial_artifacts
        if item["artifact_type"] == "BANKING_OPTION_MATRIX"
    )
    initial_minimum = next(
        item
        for item in initial_matrix["payload"]["candidates"][0]["criteria"]
        if item["code"] == "MINIMUM_AMOUNT"
    )
    proposal = next(
        item
        for item in initial_artifacts
        if item["artifact_type"] == "BANKING_PRECHECK_SUBMISSION_PROPOSAL"
    )
    assert initial_request["payload"]["need_types"] == ["PERFORMANCE_BOND"]
    assert initial_request["payload"]["credit_case_id"] == "CR-002"
    assert initial_request["payload"]["requested_amount"] == (
        PLANNER_PERFORMANCE_BOND_AMOUNT
    )
    assert initial_request["payload"]["requested_amount_currency"] == "VND"
    assert initial_request["payload"]["amount_semantics"] == (
        "CREDIT_PROFILE_REQUESTED_AMOUNT"
    )
    assert len(initial_request["payload"]["amount_evidence_ids"]) == 1
    assert initial_matrix["version"] == 1
    assert initial_matrix["payload"]["requested_amount"] == (
        PLANNER_PERFORMANCE_BOND_AMOUNT
    )
    assert initial_matrix["payload"]["requested_amount_currency"] == "VND"
    assert initial_matrix["payload"]["data_gaps"] == []
    assert initial_minimum["status"] == "PASS"
    assert proposal["payload"]["requested_amount"] == (
        PLANNER_PERFORMANCE_BOND_AMOUNT
    )
    assert proposal["payload"]["requested_amount_currency"] == "VND"
    assert not any(
        item["artifact_type"] == "BANKING_INPUT_SUPPLEMENT"
        for item in initial_artifacts
    )
    approval_requests = workflow_client.get(
        f"/api/cases/{case_id}/approval-requests"
    ).json()
    approval_request = next(
        item
        for item in approval_requests
        if item["request_id"] == paused["pending_approval_ids"][0]
    )
    assert approval_request["command"]["payload"] == {
        "precheck_submission_requested": True,
        "api_ids": ["API-002"],
        "requested_amount": PLANNER_PERFORMANCE_BOND_AMOUNT,
        "requested_amount_currency": "VND",
    }
    checkpoint_payload = workflow_client.get(
        f"/api/cases/{case_id}/approval-checkpoints"
    ).json()
    checkpoints_by_id = {
        item["checkpoint_id"]: item
        for item in checkpoint_payload["checkpoints"]
    }
    assert {
        checkpoints_by_id[item]["source_rule_id"]
        for item in approval_request["checkpoint_ids"]
    } == {"API-002", "RR-005"}

    final = complete_banking_pause_if_required(workflow_client, paused)
    assert final["status"] == "COMPLETED"
    assert final["current_stage"] == "DECISION_CARD_READY"
    assert final["banking_discovery_status"] == "OPTIONS_READY"
    assert final["banking_input_supplement_id"] is None
    assert final["banking_precheck_readiness_status"] == "READY"
    assert final["decision_post_banking_outcome"] == "BANKING_PRECHECK_READY"
    assert final["decision_post_precheck_outcome"] == (
        "CONDITIONAL_OPTIONS_AVAILABLE"
    )
    assert final["precheck_ready_option_ids"]
    assert final["pending_missing_data_ids"] == []
    assert final["banking_discovery_result_id"]
    assert final["banking_option_matrix_id"]
    assert final["banking_option_advice_id"]
    assert final["banking_option_count"] == 1
    assert final["banking_precheck_result_set_id"]
    assert final["banking_precheck_normalized_result_ids"]
    assert final["banking_precheck_outcomes"] == ["CONDITIONAL_PRECHECK"]
    assert final["banking_precheck_eligibility_statuses"] == ["ELIGIBLE"]
    assert final["banking_precheck_guarantee_decisions"] == ["CONDITIONAL"]
    assert final["banking_precheck_supported_amounts"] == [
        PLANNER_PERFORMANCE_BOND_AMOUNT
    ]
    assert final["document_release_package_ready"] is True
    assert final["internal_decision_package_ready"] is True
    assert final["internal_decision_assembly_path"] == (
        "CONDITIONAL_DOCUMENT_READY"
    )
    assert final["ready_for_internal_decision"] is True
    assert final["document_release_authorized"] is False
    assert final["document_external_release_performed"] is False
    assert final["final_risk_assessment_id"]
    assert final["final_risk_status"] == "LIMITED_BY_EVIDENCE"
    assert final["final_residual_risk_level"] == "HIGH"
    assert final["final_risk_conclusion"] == "ATTENTION_REQUIRED"
    assert final["final_major_exception"] == "NOT_EVALUABLE"
    assert final["final_unresolved_approval_gate_ids"] == []
    assert final["ai_decision_analysis_id"]
    assert final["ai_decision_analysis_source"] == "DETERMINISTIC_FALLBACK"
    assert final["decision_card_id"]
    assert final["decision_recommendation"] == "NOT_EVALUABLE"
    assert final["post_decision_update_id"] is None
    assert final["external_document_submission_proposal_id"] is None
    assert final["external_submission_authorized"] is False
    assert final["ready_for_external_submission"] is False
    assert final["external_submission_performed"] is False
    assert {
        "SIMULATED_BANKING_RESULT_IS_NON_BINDING",
        "DOCUMENT_RELEASE_REQUIRES_SEPARATE_AUTHORIZATION",
    }.issubset(set(final["final_required_control_codes"]))
    assert final["banking_precheck_execution_mode"] == "SIMULATED"
    assert (
        final["banking_precheck_result_authority"]
        == "SIMULATED_NON_BINDING"
    )
    assert final["banking_precheck_external_bank_submission"] is False
    assert final["banking_precheck_bank_approval_obtained"] is False
    # Two Risk checkpoints are registered during the scan.  The exact banking
    # proposal later adds one API-policy checkpoint and one amount checkpoint.
    assert final["approval_checkpoint_count"] == 4
    assert final["pending_approval_ids"] == []
    node_status = {item["node"]: item["status"] for item in final["nodes"]}
    assert set(node_status) == {
        "PLANNER_INTAKE",
        "INITIAL_RISK_PRE_SCAN",
        "FINANCE_ASSESSMENT",
        "OPERATIONS_ASSESSMENT",
        "INITIAL_RISK_FINALIZATION",
        "DECISION_ROUTE_PLANNING",
        "BANKING_DISCOVERY_HANDOFF",
        "BANKING_INTERNAL_DISCOVERY",
        "BANKING_PRECHECK_READINESS",
        "DECISION_POST_BANKING_REVIEW",
        "BANKING_PRECHECK_SUBMISSION_PROPOSAL",
        "BANKING_PRECHECK_EXECUTION",
        "DECISION_POST_PRECHECK_REVIEW",
        "DECISION_DOCUMENT_HANDOFF",
        "DOCUMENT_PREPARATION",
        "DOCUMENT_INPUT_INTAKE",
        "INTERNAL_DECISION_PACKAGE_ASSEMBLY",
        "FINAL_RISK_CHECK",
        "DECISION_CARD_COMPOSITION",
        "APPROVAL_GATE",
    }
    assert all(
        status in {"COMPLETED", "COMPLETED_WITH_WARNINGS"}
        for status in node_status.values()
    )
    artifact_types = {item["artifact_type"] for item in final["artifact_refs"]}
    assert {
        "PLANNER_RESULT",
        "EVALUATION_CASE",
        "FINANCE_FACTS",
        "FINANCE_ASSESSMENT",
        "OPERATIONS_FACTS",
        "OPERATIONS_ASSESSMENT",
        "RISK_PRE_SCAN",
        "APPROVAL_CHECKPOINTS",
        "RISK_RULE_EVALUATION",
        "INITIAL_RISK_ASSESSMENT",
        "DECISION_ROUTE_PLAN",
        "BANKING_DISCOVERY_REQUEST",
        "BANKING_OPTION_MATRIX",
        "BANKING_DISCOVERY_RESULT",
        "BANKING_OPTION_ADVICE",
        "BANKING_PRECHECK_READINESS",
        "DECISION_POST_BANKING_REVIEW",
        "BANKING_PRECHECK_SUBMISSION_PROPOSAL",
        "BANKING_PRECHECK_RESULT_SET",
        "DECISION_POST_PRECHECK_REVIEW",
        "DOCUMENT_PREPARATION_REQUEST",
        "DOCUMENT_CHECKLIST",
        "DOCUMENT_PACKAGE_DRAFT",
        "DOCUMENT_EVIDENCE_SUPPLEMENT",
        "DOCUMENT_RELEASE_PACKAGE",
        "INTERNAL_DECISION_PACKAGE",
        "FINAL_RISK_ASSESSMENT",
        "AI_DECISION_ANALYSIS",
        "DECISION_CARD",
    }.issubset(artifact_types)
    final_artifacts = workflow_client.get(f"/api/cases/{case_id}/artifacts").json()
    decision_card = next(
        item
        for item in final_artifacts
        if item["artifact_type"] == "DECISION_CARD"
        and item["payload"]["decision_card_id"] == final["decision_card_id"]
    )
    dashboard_response = workflow_client.get(
        f"/api/workflows/{final['workflow_run_id']}/dashboard"
    )
    assert dashboard_response.status_code == 200
    dashboard = dashboard_response.json()
    not_evaluable_review = next(
        item
        for item in dashboard["pending_interactions"]
        if item["interaction_type"] == "NOT_EVALUABLE_REVIEW"
    )
    assert not_evaluable_review["subject_artifact_id"] == decision_card["artifact_id"]
    assert not_evaluable_review["subject_artifact_version"] == decision_card["version"]
    assert not_evaluable_review["request_ids"] == []
    assert not_evaluable_review["approval_request_ids"] == []
    assert not_evaluable_review["protected_action"] is None
    assert not_evaluable_review["endpoint"] is None
    assert not_evaluable_review["required_fields"] == []
    assert "các bước sau quyết định không được mở" in (
        not_evaluable_review["instruction_vi"]
    )
    requests = [
        item
        for item in final_artifacts
        if item["artifact_type"] == "BANKING_DISCOVERY_REQUEST"
    ]
    matrices = [
        item
        for item in final_artifacts
        if item["artifact_type"] == "BANKING_OPTION_MATRIX"
    ]
    assert len(requests) == 1
    assert requests[0]["payload"]["requested_amount"] == (
        PLANNER_PERFORMANCE_BOND_AMOUNT
    )
    assert requests[0]["payload"]["requested_amount_currency"] == "VND"
    assert len(matrices) == 1
    assert matrices[0]["version"] == 1
    assert matrices[0]["payload"]["requested_amount"] == (
        PLANNER_PERFORMANCE_BOND_AMOUNT
    )
    assert matrices[0]["payload"]["data_gaps"] == []
    assert sum(
        item["artifact_type"] == "BANKING_INPUT_SUPPLEMENT"
        for item in final_artifacts
    ) == 0
    assert sum(
        item["artifact_type"] == "BANKING_PRECHECK_SUBMISSION_PROPOSAL"
        for item in final_artifacts
    ) == 1
    approval_requests = workflow_client.get(
        f"/api/cases/{case_id}/approval-requests"
    ).json()
    assert any(
        item["command"]["action_type"] == "SUBMIT_BANKING_PRECHECK"
        and item["status"] == "APPROVED"
        for item in approval_requests
    )
    assert not any(
        item["command"]["action_type"]
        in {
            "CONFIRM_FINAL_CONTRACT_DECISION",
            "SEND_DOCUMENT_TO_EXTERNAL_PARTNER",
        }
        for item in approval_requests
    )
    events = workflow_client.get(
        f"/api/workflows/{paused['workflow_run_id']}/events"
    ).json()
    assert [item["event_type"] for item in events].count(
        "BANKING_INPUT_SUPPLEMENT_ACCEPTED"
    ) == 0
    assert [item["event_type"] for item in events].count(
        "APPROVAL_REQUESTED"
    ) == 1
    assert "DOCUMENT_RELEASE_PACKAGE_READY" in {
        item["event_type"] for item in events
    }
    assert "FINAL_RISK_CHECK_COMPLETED" in {
        item["event_type"] for item in events
    }
    assert not {
        "DOCUMENT_EXTERNAL_RELEASE_PROPOSAL",
        "DOCUMENT_EXTERNAL_RELEASE_AUTHORIZED",
        "DOCUMENT_EXTERNAL_RELEASE_DECLINED",
    }.intersection(item["event_type"] for item in events)
    assert compute_sha256(TEAM_PACK) == before


def test_duplicate_start_reuses_workflow_and_does_not_repeat_nodes(
    workflow_client: TestClient,
) -> None:
    first = start(workflow_client, "CON-005")
    final = complete_banking_pause_if_required(
        workflow_client,
        wait_for_terminal(workflow_client, str(first["workflow_run_id"])),
    )
    second_started = start(workflow_client, "CON-005")
    second = wait_for_terminal(
        workflow_client, str(second_started["workflow_run_id"])
    )

    assert second_started["workflow_run_id"] == first["workflow_run_id"]
    assert second["workflow_run_id"] == first["workflow_run_id"]
    assert second["status"] == "COMPLETED"
    nodes = {item["node"]: item for item in final["nodes"]}
    assert nodes["PLANNER_INTAKE"]["attempt"] == 1
    assert nodes["FINANCE_ASSESSMENT"]["attempt"] == 1
    assert nodes["OPERATIONS_ASSESSMENT"]["attempt"] == 1
    assert nodes["INITIAL_RISK_PRE_SCAN"]["attempt"] == 1
    assert nodes["INITIAL_RISK_FINALIZATION"]["attempt"] == 1
    assert nodes["DECISION_ROUTE_PLANNING"]["attempt"] == 1
    second_nodes = {item["node"]: item for item in second["nodes"]}
    assert second_nodes["DECISION_CARD_COMPOSITION"]["attempt"] == 1
    assert second["artifact_refs"] == final["artifact_refs"]
    expected_completion_count = (
        2 if second_started["status"] == "PENDING" else 1
    )
    deadline = time.monotonic() + 2
    events: list[dict[str, object]] = []
    while time.monotonic() < deadline:
        events = workflow_client.get(
            f"/api/workflows/{first['workflow_run_id']}/events"
        ).json()
        if [item["event_type"] for item in events].count(
            "WORKFLOW_COMPLETED"
        ) >= expected_completion_count:
            break
        time.sleep(0.01)
    assert [item["event_type"] for item in events].count("WORKFLOW_CREATED") == 1
    assert [item["event_type"] for item in events].count(
        "WORKFLOW_COMPLETED"
    ) == expected_completion_count
    assert [item["event_type"] for item in events].count("DECISION_CARD_READY") == 1
    dependency_waits = [
        item
        for item in events
        if item["event_type"] == "NODE_WAITING"
        and item["node"] == "INITIAL_RISK_FINALIZATION"
    ]
    assert len(dependency_waits) == 1
    assert dependency_waits[0]["metadata"]["waiting_for"] == [
        "FINANCE_FACTS",
        "OPERATIONS_FACTS",
    ]


def test_duplicate_banking_start_reuses_matrix_advice_and_node_attempt(
    workflow_client: TestClient,
) -> None:
    first = start(workflow_client, "CON-004")
    terminal = wait_for_terminal(workflow_client, str(first["workflow_run_id"]))
    final = complete_banking_pause_if_required(workflow_client, terminal)
    attempts_before = {
        item["node"]: item["attempt"] for item in final["nodes"]
    }
    artifact_refs_before = final["artifact_refs"]
    second_started = start(workflow_client, "CON-004")
    second = wait_for_terminal(
        workflow_client, str(second_started["workflow_run_id"])
    )

    assert second_started["workflow_run_id"] == first["workflow_run_id"]
    assert second["workflow_run_id"] == first["workflow_run_id"]
    assert second["status"] == "COMPLETED"
    after = workflow_client.get(
        f"/api/workflows/{first['workflow_run_id']}"
    ).json()
    assert {
        item["node"]: item["attempt"] for item in after["nodes"]
    } == attempts_before
    assert after["artifact_refs"] == artifact_refs_before
    artifact_types = [item["artifact_type"] for item in final["artifact_refs"]]
    assert artifact_types.count("BANKING_DISCOVERY_REQUEST") == 1
    assert artifact_types.count("BANKING_OPTION_MATRIX") == 1
    assert artifact_types.count("BANKING_DISCOVERY_RESULT") == 1
    assert artifact_types.count("BANKING_OPTION_ADVICE") == 1
    assert artifact_types.count("BANKING_PRECHECK_READINESS") == 1
    assert artifact_types.count("DECISION_POST_BANKING_REVIEW") == 1
    assert artifact_types.count("BANKING_INPUT_SUPPLEMENT") == 0
    assert artifact_types.count("BANKING_PRECHECK_SUBMISSION_PROPOSAL") == 1


def test_nonexistent_contract_waits_for_input_without_starting_downstream(
    workflow_client: TestClient,
) -> None:
    created = start(workflow_client, "CON-NOT-PRESENT")
    waiting = wait_for_terminal(workflow_client, str(created["workflow_run_id"]))

    assert waiting["status"] == "WAITING_FOR_INPUT"
    assert waiting["current_stage"] == "PLANNER_INTAKE"
    assert waiting["pending_missing_data_ids"]
    assert [item["node"] for item in waiting["nodes"]] == ["PLANNER_INTAKE"]
    assert waiting["nodes"][0]["status"] == "WAITING_FOR_INPUT"


def test_event_cursor_scope_validation_and_resume_conflict(
    workflow_client: TestClient,
) -> None:
    created = start(workflow_client, "CON-003")
    final = complete_banking_pause_if_required(
        workflow_client,
        wait_for_terminal(workflow_client, str(created["workflow_run_id"])),
    )
    workflow_id = str(created["workflow_run_id"])
    events = workflow_client.get(f"/api/workflows/{workflow_id}/events").json()
    cursor = events[len(events) // 2]["sequence"]
    after = workflow_client.get(
        f"/api/workflows/{workflow_id}/events?after_sequence={cursor}"
    ).json()

    assert final["status"] == "COMPLETED"
    assert after
    assert all(item["sequence"] > cursor for item in after)
    assert workflow_client.post(f"/api/workflows/{workflow_id}/resume").status_code == 409
    invalid_scope = workflow_client.post(
        "/api/cases/run",
        json={"contract_id": "CON-003", "evaluation_scope": ["FINANCE"]},
    )
    assert invalid_scope.status_code == 422


def test_every_contract_can_complete_through_the_automatic_workflow(
    workflow_client: TestClient,
) -> None:
    contract_ids = workflow_client.get("/api/contracts").json()["contract_ids"]

    for contract_id in contract_ids:
        created = start(workflow_client, contract_id)
        terminal = wait_for_terminal(
            workflow_client, str(created["workflow_run_id"])
        )
        final = complete_banking_pause_if_required(workflow_client, terminal)
        assert final["status"] == "COMPLETED"


def test_swagger_exposes_each_workflow_route_once(workflow_client: TestClient) -> None:
    paths = workflow_client.get("/openapi.json").json()["paths"]
    methods = {
        "/api/cases/run": "post",
        "/api/workflows/{workflow_run_id}": "get",
        "/api/workflows/{workflow_run_id}/resume": "post",
        "/api/workflows/{workflow_run_id}/events": "get",
    }

    for path, method in methods.items():
        assert path in paths
        assert list(paths[path]) == [method]
        assert paths[path][method]["tags"] == ["Workflow"]


def test_pending_workflow_recovers_after_runtime_restart(
    tmp_path: Path,
) -> None:
    dataset_id = "WORKFLOW_RESTART_TEST"
    database_path = tmp_path / "workflow-restart.db"
    async def snapshot_hash() -> str:
        datasets = InMemoryDatasetRepository()
        snapshot = await ExcelDatasetIngestion(datasets).ingest(
            dataset_id=dataset_id,
            workbook_path=TEAM_PACK,
        )
        return snapshot.snapshot_hash

    active_snapshot_hash = asyncio.run(snapshot_hash())
    now = datetime.now(UTC)
    seeded = CaseWorkflowRun(
        workflow_run_id="CWF-RECOVERY-TEST",
        dataset_id=dataset_id,
        dataset_snapshot_hash=active_snapshot_hash,
        contract_id="CON-004",
        status=WorkflowStatus.PENDING,
        current_stage=WorkflowNode.PLANNER_INTAKE.value,
        requested_scope=(
            EvaluationScope.FINANCE,
            EvaluationScope.OPERATIONS,
            EvaluationScope.RISK,
        ),
        as_of_date=datetime(2026, 7, 16).date(),
        created_at=now,
        updated_at=now,
    )

    async def seed() -> None:
        database = SQLiteDatabase(database_path)
        await database.initialize()
        await SQLiteCaseWorkflowRepository(database).save_run(seeded)
        await database.close()

    asyncio.run(seed())
    patcher = pytest.MonkeyPatch()
    patcher.setenv("OPENAI_ENABLED", "false")
    patcher.setenv("OPC_MIS_MASKING_HMAC_KEY_BASE64", TEST_HMAC_KEY)
    try:
        with TestClient(
            create_app(
                workbook_path=TEAM_PACK,
                dataset_id=dataset_id,
                database_path=database_path,
            )
        ) as client:
            terminal = wait_for_terminal(client, seeded.workflow_run_id)
            completed = complete_banking_pause_if_required(client, terminal)
            assert completed["status"] == "COMPLETED"
            assert completed["current_stage"] == "DECISION_CARD_READY"
            assert completed["decision_recommendation"] == "NOT_EVALUABLE"
            assert completed["final_risk_assessment_id"]
            assert completed["final_risk_status"] == "LIMITED_BY_EVIDENCE"
            assert completed["final_residual_risk_level"] == "HIGH"
            assert completed["final_risk_conclusion"] == "ATTENTION_REQUIRED"
            assert completed["final_major_exception"] == "NOT_EVALUABLE"
            assert completed["banking_precheck_result_set_id"]
            assert completed["decision_post_precheck_review_id"]
            assert completed["banking_precheck_execution_mode"] == "SIMULATED"
            assert completed["banking_precheck_external_bank_submission"] is False
            assert completed["banking_precheck_bank_approval_obtained"] is False
            artifact_ids = {
                item["artifact_id"] for item in completed["artifact_refs"]
            }

        with TestClient(
            create_app(
                workbook_path=TEAM_PACK,
                dataset_id=dataset_id,
                database_path=database_path,
            )
        ) as restarted:
            restored = restarted.get(
                f"/api/workflows/{seeded.workflow_run_id}"
            ).json()
            assert restored["status"] == "COMPLETED"
            assert restored["current_stage"] == "DECISION_CARD_READY"
            assert restored["final_risk_assessment_id"] == completed[
                "final_risk_assessment_id"
            ]
            assert {
                item["artifact_id"] for item in restored["artifact_refs"]
            } == artifact_ids
    finally:
        patcher.undo()
