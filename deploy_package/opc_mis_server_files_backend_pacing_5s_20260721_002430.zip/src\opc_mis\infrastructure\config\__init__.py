"""Server-owned configuration adapters."""
