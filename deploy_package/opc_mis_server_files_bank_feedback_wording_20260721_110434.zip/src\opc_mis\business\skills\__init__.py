"""Deterministic business skills."""
