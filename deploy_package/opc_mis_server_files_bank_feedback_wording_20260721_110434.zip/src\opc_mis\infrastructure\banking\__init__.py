"""Banking infrastructure adapters."""

